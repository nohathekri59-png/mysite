import { useToast } from "@/hooks/use-toast";
import { AnimatePresence, motion } from "framer-motion";
import { CheckCircle2, XCircle } from "lucide-react";

export function Toaster() {
  const { toasts } = useToast();

  return (
    <div className="fixed bottom-4 right-4 z-[100] flex flex-col gap-2 w-full max-w-sm pointer-events-none px-4 sm:px-0">
      <AnimatePresence>
        {toasts.map((t) => (
          <motion.div
            key={t.id}
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
            className={`
              pointer-events-auto flex items-start gap-3 p-4 rounded-xl shadow-xl border
              backdrop-blur-md overflow-hidden
              ${t.variant === "destructive" 
                ? "bg-red-950/80 border-red-500/50 text-red-100" 
                : "bg-card/90 border-primary/50 text-foreground gold-glow"}
            `}
          >
            {t.variant === "destructive" ? (
              <XCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            ) : (
              <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-0.5" />
            )}
            <div className="flex-1">
              {t.title && <h4 className="font-semibold text-sm">{t.title}</h4>}
              {t.description && (
                <p className="text-sm opacity-90 font-arabic mt-1">{t.description}</p>
              )}
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
