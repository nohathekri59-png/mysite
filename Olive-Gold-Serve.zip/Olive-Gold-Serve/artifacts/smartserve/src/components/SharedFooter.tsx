import { useT } from "@/lib/i18n";

export function SharedFooter() {
  const t = useT();
  return (
    <footer className="w-full py-6 px-4 border-t border-primary/10 bg-background/60 backdrop-blur-sm">
      <p className="text-center text-xs sm:text-sm text-primary/70 tracking-wide">
        <span className="font-light">
          {t("All Rights Reserved © 2026 — ", "جميع الحقوق محفوظة © 2026 — ")}
        </span>
        <span className="font-arabic font-medium">
          {t("Designed by Noha Zekry", "إعداد نهى ذكري")}
        </span>
      </p>
    </footer>
  );
}
