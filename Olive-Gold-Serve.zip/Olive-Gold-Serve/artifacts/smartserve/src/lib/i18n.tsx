import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { Languages } from "lucide-react";

export type Lang = "en" | "ar";
export type Dir  = "ltr" | "rtl";

type LangCtx = {
  lang: Lang;
  dir:  Dir;
  setLang: (l: Lang) => void;
  toggle: () => void;
};

const Ctx = createContext<LangCtx>({
  lang: "en",
  dir:  "ltr",
  setLang: () => {},
  toggle:  () => {},
});

const STORAGE_KEY = "smartserve_lang";

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(() => {
    if (typeof window === "undefined") return "en";
    const stored = localStorage.getItem(STORAGE_KEY) as Lang | null;
    return stored === "ar" || stored === "en" ? stored : "en";
  });

  const dir: Dir = lang === "ar" ? "rtl" : "ltr";

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir  = dir;
    localStorage.setItem(STORAGE_KEY, lang);
  }, [lang, dir]);

  const setLang  = useCallback((l: Lang) => setLangState(l), []);
  const toggle   = useCallback(() => setLangState((l) => (l === "en" ? "ar" : "en")), []);

  const value = useMemo(() => ({ lang, dir, setLang, toggle }), [lang, dir, setLang, toggle]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export const useLang = () => useContext(Ctx);

/** Inline translator — returns the value matching the current language. */
export function useT() {
  const { lang } = useLang();
  return function t<T>(en: T, ar: T): T {
    return lang === "ar" ? ar : en;
  };
}

/** Header-mounted toggle that switches the entire UI between EN ↔ AR. */
export function LangToggle({ className = "" }: { className?: string }) {
  const { lang, toggle } = useLang();
  return (
    <button
      type="button"
      onClick={toggle}
      aria-label="Switch language"
      title={lang === "en" ? "التبديل إلى العربية" : "Switch to English"}
      className={
        "inline-flex items-center gap-2 px-3 sm:px-4 py-2 bg-primary/10 hover:bg-primary/20 " +
        "border border-primary/40 rounded-lg text-primary font-semibold text-sm transition-all " +
        "active:scale-95 " + className
      }
    >
      <Languages className="w-4 h-4" />
      <span className={lang === "en" ? "font-arabic" : ""}>
        {lang === "en" ? "العربية" : "English"}
      </span>
    </button>
  );
}
