import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background text-foreground">
      <div className="text-center">
        <h1 className="text-8xl font-bold text-primary mb-4">404</h1>
        <h2 className="text-2xl font-semibold mb-2">Page Not Found</h2>
        <p className="text-muted-foreground font-arabic mb-8">الصفحة غير موجودة</p>
        
        <Link href="/">
          <button className="px-6 py-3 bg-card border border-primary text-primary rounded-full font-medium hover:bg-primary hover:text-primary-foreground transition-all flex items-center justify-center gap-2 mx-auto">
            <ArrowLeft className="w-4 h-4" />
            Back to Home / العودة للرئيسية
          </button>
        </Link>
      </div>
    </div>
  );
}
