import { useState, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  X, Check, Download, ShieldCheck, Sparkles, ArrowRight, Clock,
  Zap, ShoppingCart, QrCode, ChevronDown, Activity, Crown,
  Headphones, Gift, Mail, Phone as PhoneIcon, User as UserIcon, Lock,
  GraduationCap, Calculator, MessageCircle, Copy, Star, Quote, Plus,
} from "lucide-react";
import jsPDF from "jspdf";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useSignUp } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { SharedFooter } from "@/components/SharedFooter";
import { LangToggle, useLang, useT } from "@/lib/i18n";
import { cn } from "@/lib/utils";

// ════════════════════════════════════════════════════════════════════════════
// CONSTANTS
// ════════════════════════════════════════════════════════════════════════════
const WHATSAPP_NUMBER = "201276387146";
const WHATSAPP_URL    = `https://wa.me/${WHATSAPP_NUMBER}`;
const INSTAPAY_NUMBER = "01276387146";
const VODAFONE_NUMBER = "01002081026";

// ════════════════════════════════════════════════════════════════════════════
// TYPES + DATA HOOKS (bilingual)
// ════════════════════════════════════════════════════════════════════════════
type IndustryKey = "schools" | "hospitals" | "clinics" | "cafes" | "retail";
type Industry    = { key: IndustryKey; label: string };
type Tier        = { name: string; price: string; features: string[] };
type FAQ         = { q: string; a: string };

type Service = {
  id: string;
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  tagline: string;
  price: string;
  description: string;
  features: Record<IndustryKey, string[]>;
  tiers?: Tier[];
  faq: FAQ[];
};

function useIndustries(): Industry[] {
  const t = useT();
  return useMemo(() => [
    { key: "schools",   label: t("Schools",   "المدارس") },
    { key: "hospitals", label: t("Hospitals", "المستشفيات") },
    { key: "clinics",   label: t("Clinics",   "العيادات") },
    { key: "cafes",     label: t("Cafes",     "المقاهي والمطاعم") },
    { key: "retail",    label: t("Retail",    "المتاجر") },
  ], [t]);
}

function useServices(): Service[] {
  const t = useT();

  const COMMON_FAQ: FAQ[] = [
    {
      q: t("Is there a free trial?", "هل تتوفر تجربة مجانية؟"),
      a: t(
        "Yes — every service includes a free trial preview so you can experience it before purchasing.",
        "نعم — كل خدمة تشمل تجربة مجانية لتجربتها قبل الشراء."
      ),
    },
    {
      q: t("How quickly can it be deployed?", "ما هي مدة التنفيذ؟"),
      a: t(
        "Most projects launch within 5–10 business days, depending on scope and content readiness.",
        "تُطلق معظم المشاريع خلال 5 إلى 10 أيام عمل حسب حجم المشروع وجاهزية المحتوى."
      ),
    },
    {
      q: t("Do you offer Arabic & English?", "هل المنصات ثنائية اللغة؟"),
      a: t(
        "Every platform is fully bilingual by default — built mobile-first with RTL/LTR support.",
        "كل المنصات ثنائية اللغة افتراضياً — مصممة بأولوية الجوال مع دعم اتجاه RTL وLTR."
      ),
    },
  ];

  return useMemo<Service[]>(() => [
    // ─── Educational Suite ────────────────────────────────────────
    {
      id: "education",
      icon: GraduationCap,
      title:   t("Educational Suite", "حزمة الخدمات التعليمية"),
      tagline: t("Student registration, attendance & reporting", "تسجيل الطلاب والحضور والتقارير الإلكترونية"),
      price:   t("8,000 EGP / month", "٨٬٠٠٠ ج.م / شهر"),
      description: t(
        "A complete digital backbone for modern schools — from electronic registration and live attendance to automated grade reports and parent communication.",
        "بنية رقمية متكاملة للمدارس الحديثة — من التسجيل الإلكتروني والحضور المباشر إلى التقارير الآلية والتواصل مع أولياء الأمور."
      ),
      features: {
        schools: [
          t("Electronic student registration & enrollment", "تسجيل الطلاب وقيدهم إلكترونياً"),
          t("Live attendance tracking (per class, per period)", "متابعة الحضور المباشر لكل فصل وحصة"),
          t("Automated report cards & grade analytics", "تقارير الدرجات الآلية وتحليلها"),
          t("Parent portal with messaging & announcements", "بوابة أولياء الأمور مع المراسلة والإعلانات"),
          t("Teacher schedules and substitution management", "جداول المعلمين وإدارة الاحتياط"),
          t("Transport & cafeteria modules (optional add-on)", "وحدات النقل والمقصف (إضافة اختيارية)"),
        ],
        hospitals: [
          t("Staff training & onboarding records", "سجلات تدريب الموظفين وانضمامهم"),
          t("Continuing education attendance tracking", "متابعة حضور التعليم المستمر"),
          t("Certification reminders & reports", "تذكيرات وتقارير الشهادات"),
          t("Internal LMS for medical teams", "نظام تعليم داخلي للفرق الطبية"),
          t("Compliance dashboards", "لوحات الامتثال"),
        ],
        clinics: [
          t("Internal staff training records", "سجلات تدريب الفريق الداخلي"),
          t("Patient education content library", "مكتبة محتوى تثقيفي للمرضى"),
          t("Appointment-linked education delivery", "محتوى تعليمي مرتبط بالمواعيد"),
          t("Compliance and certification logs", "سجلات الامتثال والشهادات"),
        ],
        cafes: [
          t("Staff training & barista certification logs", "تدريب العاملين وشهادات الباريستا"),
          t("Onboarding workflow for new hires", "خطة دمج الموظفين الجدد"),
          t("Performance review tracking", "متابعة تقييمات الأداء"),
        ],
        retail: [
          t("Staff product-knowledge training", "تدريب الفريق على المنتجات"),
          t("Sales certification tracking", "متابعة شهادات المبيعات"),
          t("Onboarding & compliance modules", "وحدات الدمج والامتثال"),
        ],
      },
      faq: [
        {
          q: t("Can parents access their child's data?", "هل يستطيع أولياء الأمور رؤية بيانات أبنائهم؟"),
          a: t(
            "Yes — each parent gets a secure portal with grades, attendance, schedule, and messaging.",
            "نعم — لكل ولي أمر بوابة آمنة تعرض الدرجات والحضور والجدول والمراسلة."
          ),
        },
        {
          q: t("Is bulk student import supported?", "هل يدعم الاستيراد المجمّع للطلاب؟"),
          a: t(
            "Absolutely — upload via Excel/CSV or sync from your existing SIS.",
            "بكل تأكيد — رفع ملفات Excel/CSV أو المزامنة مع نظامك الحالي."
          ),
        },
        ...COMMON_FAQ,
      ],
    },

    // ─── Smart Accounting ─────────────────────────────────────────
    {
      id: "accounting",
      icon: Calculator,
      title:   t("Smart Accounting System", "نظام المحاسبة الذكي"),
      tagline: t("Tiered accounting — Basic · Pro · Enterprise", "نظام محاسبة متدرج — أساسي ومحترف ومؤسسي"),
      price:   t("From 6,000 EGP", "ابتداءً من ٦٬٠٠٠ ج.م"),
      description: t(
        "Modern double-entry accounting with invoicing, taxes, payroll, and live reporting. Choose the tier that matches your size — and upgrade anytime.",
        "محاسبة احترافية مزدوجة القيد مع الفوترة والضرائب والرواتب والتقارير المباشرة. اختر الباقة التي تناسبك — وقم بالترقية في أي وقت."
      ),
      tiers: [
        {
          name:  t("Basic", "أساسي"),
          price: t("6,000 EGP", "٦٬٠٠٠ ج.م"),
          features: [
            t("Up to 500 transactions / month", "حتى ٥٠٠ معاملة / شهر"),
            t("Invoicing & receipts", "الفوترة وإيصالات الاستلام"),
            t("Basic VAT & tax reports", "تقارير ضريبة القيمة المضافة الأساسية"),
            t("Single-user access", "مستخدم واحد"),
            t("Email support", "دعم عبر البريد الإلكتروني"),
          ],
        },
        {
          name:  t("Pro", "احترافي"),
          price: t("12,000 EGP", "١٢٬٠٠٠ ج.م"),
          features: [
            t("Unlimited transactions", "معاملات غير محدودة"),
            t("Multi-user access (up to 5)", "حتى ٥ مستخدمين"),
            t("Payroll & employee records", "الرواتب وسجلات الموظفين"),
            t("Multi-currency support", "دعم عدة عملات"),
            t("Inventory & cost-of-goods tracking", "متابعة المخزون وتكلفة البضاعة"),
            t("Priority support", "دعم ذو أولوية"),
          ],
        },
        {
          name:  t("Enterprise", "مؤسسي"),
          price: t("20,000 EGP", "٢٠٬٠٠٠ ج.م"),
          features: [
            t("Unlimited users & branches", "مستخدمون وفروع غير محدودة"),
            t("Advanced reporting & dashboards", "تقارير ولوحات متقدمة"),
            t("API & ERP integrations", "تكاملات API و ERP"),
            t("Custom workflows & approvals", "سير عمل وموافقات مخصصة"),
            t("Dedicated account manager", "مدير حساب مخصص"),
            t("24/7 priority support", "دعم على مدار الساعة بأولوية قصوى"),
          ],
        },
      ],
      features: {
        schools: [
          t("Tuition invoicing & installment plans", "فوترة المصروفات وأقساط الدفع"),
          t("Staff payroll automation", "أتمتة رواتب الموظفين"),
          t("Donation & fundraising tracking", "متابعة التبرعات والتمويل"),
          t("Department-level budget reports", "تقارير الميزانية حسب القسم"),
        ],
        hospitals: [
          t("Patient billing & insurance claims", "فوترة المرضى ومطالبات التأمين"),
          t("Department-level P&L reporting", "تقارير الأرباح والخسائر حسب القسم"),
          t("Vendor & supplier accounts", "حسابات الموردين"),
          t("Payroll for medical & admin staff", "رواتب الفريق الطبي والإداري"),
        ],
        clinics: [
          t("Service-based invoicing & receipts", "فواتير وإيصالات حسب الخدمة"),
          t("Insurance claim management", "إدارة مطالبات التأمين"),
          t("Daily revenue dashboard", "لوحة الإيرادات اليومية"),
          t("Tax-ready reports", "تقارير جاهزة للضرائب"),
        ],
        cafes: [
          t("Daily sales & cash reconciliation", "المبيعات اليومية ومطابقة النقدية"),
          t("Inventory cost & wastage tracking", "تكلفة المخزون ومتابعة الهدر"),
          t("Multi-branch consolidated reporting", "تقارير موحّدة لعدة فروع"),
          t("Staff payroll & tip distribution", "رواتب الموظفين وتوزيع البقشيش"),
        ],
        retail: [
          t("POS integration & live sales sync", "تكامل نقاط البيع ومزامنة المبيعات"),
          t("Inventory valuation & stock reports", "تقييم المخزون وتقارير الكميات"),
          t("Multi-branch financial dashboards", "لوحات مالية لعدة فروع"),
          t("Tax & VAT automation", "أتمتة الضرائب وضريبة القيمة المضافة"),
        ],
      },
      faq: [
        {
          q: t("Can I migrate from QuickBooks / Excel?", "هل يمكن الانتقال من QuickBooks أو Excel؟"),
          a: t(
            "Yes — we offer a guided migration with chart-of-accounts mapping included in onboarding.",
            "نعم — نقدم نقلاً موجهاً مع تعيين دليل الحسابات ضمن مرحلة الانضمام."
          ),
        },
        {
          q: t("Is it Egyptian Tax Authority compliant?", "هل النظام متوافق مع مصلحة الضرائب المصرية؟"),
          a: t(
            "All tiers produce ETA-compliant invoices and VAT reports out of the box.",
            "جميع الباقات تنتج فواتير وتقارير ضريبية متوافقة مع مصلحة الضرائب."
          ),
        },
        ...COMMON_FAQ,
      ],
    },

    // ─── Enterprise Platform ──────────────────────────────────────
    {
      id: "enterprise",
      icon: Crown,
      title:   t("Enterprise Platform", "منصة متكاملة"),
      tagline: t("Full-scale e-commerce + dashboard + database", "متجر إلكتروني كامل ولوحة تحكم وقاعدة بيانات"),
      price:   t("10,000 EGP", "١٠٬٠٠٠ ج.م"),
      description: t(
        "An end-to-end digital platform engineered for organizations that demand scale, automation, and total control. Includes complete back-office, secure payments, role-based access, and real-time analytics.",
        "منصة رقمية متكاملة للشركات التي تتطلب النمو والأتمتة والتحكم الكامل. تشمل لوحة تحكم خلفية ومدفوعات آمنة وصلاحيات حسب الدور وتحليلات لحظية."
      ),
      features: {
        schools: [
          t("Student & parent portals with role-based access", "بوابات الطلاب وأولياء الأمور بصلاحيات مختلفة"),
          t("Online enrollment and tuition payments", "التسجيل ودفع المصروفات إلكترونياً"),
          t("Grade management & report card automation", "إدارة الدرجات وتقارير آلية"),
          t("Internal messaging and announcements", "مراسلات وإعلانات داخلية"),
          t("Attendance dashboards and analytics", "لوحات حضور وتحليلات"),
        ],
        hospitals: [
          t("Patient records (EMR) with HIPAA-style controls", "سجلات المرضى الإلكترونية بمعايير حماية مرتفعة"),
          t("Appointment scheduling across departments", "جدولة المواعيد بين الأقسام"),
          t("Billing, insurance claims, and invoicing", "الفوترة ومطالبات التأمين"),
          t("Pharmacy & inventory management", "إدارة الصيدلية والمخزون"),
          t("Doctor and staff workforce dashboard", "لوحة لإدارة الأطباء والفريق"),
        ],
        clinics: [
          t("Online appointment booking & reminders", "حجز المواعيد إلكترونياً والتذكيرات"),
          t("Patient history and consultation notes", "السجل الطبي وملاحظات الكشف"),
          t("Integrated payments and receipts", "مدفوعات وإيصالات متكاملة"),
          t("Prescription PDF generation", "إصدار الروشتات بصيغة PDF"),
          t("Performance analytics for the clinic", "تحليلات أداء العيادة"),
        ],
        cafes: [
          t("Multi-branch order & inventory management", "إدارة الطلبات والمخزون لعدة فروع"),
          t("Loyalty program with custom rewards", "برنامج ولاء بمكافآت قابلة للتخصيص"),
          t("Online ordering with table mapping", "طلب إلكتروني مع رسم خريطة الطاولات"),
          t("Staff scheduling and tip distribution", "جدولة الفريق وتوزيع البقشيش"),
          t("Sales analytics and forecasting", "تحليلات وتوقعات مبيعات"),
        ],
        retail: [
          t("Full e-commerce storefront with checkout", "متجر إلكتروني كامل مع نظام دفع"),
          t("Inventory sync across physical stores", "مزامنة المخزون بين الفروع"),
          t("Customer accounts & order history", "حسابات العملاء وسجل الطلبات"),
          t("Multi-payment gateway integration", "تكامل مع عدة بوابات دفع"),
          t("Sales, returns, and tax reporting", "تقارير المبيعات والمرتجعات والضرائب"),
        ],
      },
      faq: [
        {
          q: t("Is hosting included?", "هل الاستضافة مشمولة؟"),
          a: t(
            "Yes — managed hosting, SSL, and CDN are included for the first year.",
            "نعم — استضافة مُدارة وشهادة SSL وشبكة توزيع محتوى مشمولة للسنة الأولى."
          ),
        },
        ...COMMON_FAQ,
      ],
    },

    // ─── Digital Menu — Basic ─────────────────────────────────────
    {
      id: "menu-basic",
      icon: QrCode,
      title:   t("Digital Menu — Basic", "المنيو الإلكتروني البسيط"),
      tagline: t("QR-based digital menu — view only", "عرض المنيو فقط بـ QR Code"),
      price:   t("1,500 EGP / month", "١٬٥٠٠ ج.م / شهر"),
      description: t(
        "A clean, mobile-optimized digital menu accessible via a simple QR code. Perfect for venues that want to eliminate printed menus and update offerings instantly.",
        "منيو إلكتروني أنيق متوافق مع الجوال يفتح بمسح QR. مثالي للمحلات التي تريد التخلي عن المنيو الورقي وتحديث المعروضات لحظياً."
      ),
      features: {
        schools: [
          t("Cafeteria menu with daily specials", "منيو المقصف مع أصناف اليوم"),
          t("Allergen and nutrition information", "معلومات الحساسية والقيم الغذائية"),
          t("Bilingual (English / Arabic) display", "عرض ثنائي اللغة عربي/إنجليزي"),
          t("Branded with your school colors", "تصميم بألوان مدرستك"),
          t("Update prices and items anytime", "تعديل الأصناف والأسعار في أي وقت"),
        ],
        hospitals: [
          t("Patient meal options by dietary plan", "خيارات وجبات المرضى حسب النظام الغذائي"),
          t("Cafeteria menu for visitors", "منيو المقصف للزوار"),
          t("Allergen disclosures", "بيان مكونات الحساسية"),
          t("Multi-language support", "دعم عدة لغات"),
          t("Hospital-branded layout", "تصميم بهوية المستشفى"),
        ],
        clinics: [
          t("Service & treatment price list", "قائمة أسعار الخدمات والعلاجات"),
          t("Doctor & specialty directory", "دليل الأطباء والتخصصات"),
          t("Operating hours and contact", "ساعات العمل وبيانات التواصل"),
          t("Bilingual interface", "واجهة ثنائية اللغة"),
          t("Branded with your clinic colors", "تصميم بألوان عيادتك"),
        ],
        cafes: [
          t("Beautiful menu with photos & categories", "منيو أنيق بصور وأقسام"),
          t("Live pricing & instant updates", "أسعار لحظية وتحديثات فورية"),
          t("Multi-language menu", "منيو متعدد اللغات"),
          t("QR sticker design included", "تصميم ملصق QR مشمول"),
          t("Track view counts per item", "متابعة عدد المشاهدات لكل صنف"),
        ],
        retail: [
          t("Product catalog with photos", "كتالوج منتجات بالصور"),
          t("Real-time price updates", "تحديث الأسعار في الوقت الحقيقي"),
          t("Category & search filters", "تصفية بالأقسام والبحث"),
          t("Bilingual display", "عرض ثنائي اللغة"),
          t("Branded with your store identity", "تصميم بهوية متجرك"),
        ],
      },
      faq: [
        {
          q: t("Can I update prices myself?", "هل أستطيع تحديث الأسعار بنفسي؟"),
          a: t(
            "Yes — you get an admin panel to update menu items, prices, and photos anytime.",
            "نعم — تحصل على لوحة تحكم لتعديل الأصناف والأسعار والصور في أي وقت."
          ),
        },
        ...COMMON_FAQ,
      ],
    },

    // ─── Interactive Menu ─────────────────────────────────────────
    {
      id: "menu-interactive",
      icon: ShoppingCart,
      title:   t("Interactive Menu", "المنيو التفاعلي"),
      tagline: t("Cart, dashboard & online payments", "سلة مبيعات ولوحة تحكم ودفع إلكتروني"),
      price:   t("2,800 EGP / month", "٢٬٨٠٠ ج.م / شهر"),
      description: t(
        "Take orders, accept payments, and manage operations from a single dashboard. The Interactive Menu turns any device into a complete ordering and sales channel.",
        "استقبل الطلبات وادفع المدفوعات وأدر العمليات من لوحة واحدة. المنيو التفاعلي يحول أي جهاز إلى قناة طلبات ومبيعات متكاملة."
      ),
      features: {
        schools: [
          t("Pre-order cafeteria meals from a phone", "طلب وجبات المقصف مسبقاً من الهاتف"),
          t("Parent wallet with balance top-ups", "محفظة ولي الأمر مع شحن الرصيد"),
          t("Real-time order tracking", "متابعة الطلبات في الوقت الحقيقي"),
          t("Daily sales reports for the canteen", "تقارير مبيعات يومية للمقصف"),
          t("Order history per student", "سجل طلبات لكل طالب"),
        ],
        hospitals: [
          t("In-room patient meal ordering", "طلب وجبات المرضى من الغرفة"),
          t("Visitor cafeteria orders & checkout", "طلبات الزوار وعملية الدفع"),
          t("Live kitchen dashboard", "لوحة مطبخ مباشرة"),
          t("Department-level analytics", "تحليلات على مستوى القسم"),
          t("Integrated payment processing", "معالجة مدفوعات متكاملة"),
        ],
        clinics: [
          t("Book and pay for services online", "احجز وادفع للخدمات إلكترونياً"),
          t("Order supplements or supplies", "طلب المكملات والمستلزمات"),
          t("Receipt and invoice generation", "إصدار الإيصالات والفواتير"),
          t("Patient order history", "سجل طلبات المرضى"),
          t("Daily revenue dashboard", "لوحة الإيرادات اليومية"),
        ],
        cafes: [
          t("Self-service ordering at the table", "طلب ذاتي من الطاولة"),
          t("Card, wallet, and cash on delivery", "دفع بالبطاقة أو المحفظة أو الكاش"),
          t("Live KDS dashboard for the kitchen", "لوحة KDS مباشرة للمطبخ"),
          t("Real-time sales & item analytics", "تحليلات لحظية للمبيعات والأصناف"),
          t("Discount codes & promotions engine", "محرك أكواد الخصم والعروض"),
        ],
        retail: [
          t("Add to cart and checkout instantly", "أضف للسلة وادفع فوراً"),
          t("Multi-payment options (cards/wallets)", "وسائل دفع متعددة"),
          t("Inventory updates in real time", "تحديث المخزون في الوقت الحقيقي"),
          t("Customer accounts & loyalty points", "حسابات العملاء ونقاط الولاء"),
          t("Dashboard with sales analytics", "لوحة تحكم بتحليلات المبيعات"),
        ],
      },
      faq: [
        {
          q: t("Which payment methods are supported?", "ما هي طرق الدفع المدعومة؟"),
          a: t(
            "Cards (Visa/Mastercard/Meeza), Vodafone Cash, InstaPay, and cash-on-delivery.",
            "البطاقات (فيزا/ماستركارد/ميزة) وفودافون كاش وإنستاباي والدفع عند الاستلام."
          ),
        },
        ...COMMON_FAQ,
      ],
    },
  ], [t]);
}

function useTestimonials() {
  const t = useT();
  return useMemo(() => [
    {
      name:  t("Mohamed Al-Sayed", "محمد السيد"),
      role:  t("Owner — Bella Vista Cafe", "صاحب مقهى بيلا فيستا"),
      quote: t(
        "Our orders went up 40% in the first month. The dashboard is intuitive and the team replies within minutes.",
        "زادت طلباتنا بنسبة ٤٠٪ في أول شهر. لوحة التحكم سهلة والفريق يرد خلال دقائق."
      ),
      rating: 5,
    },
    {
      name:  t("Dr. Salma Hassan", "د. سلمى حسن"),
      role:  t("Director — Wellness Medical Clinic", "مديرة عيادة ويلنس الطبية"),
      quote: t(
        "Patient bookings tripled. We finally retired our paper appointment book — the whole team loves it.",
        "تضاعفت حجوزات المرضى ثلاث مرات. تخلصنا أخيراً من دفتر المواعيد الورقي والفريق سعيد جداً."
      ),
      rating: 5,
    },
    {
      name:  t("Yara Ibrahim", "يارا إبراهيم"),
      role:  t("Principal — Horizons International School", "مديرة مدرسة الآفاق الدولية"),
      quote: t(
        "Parent satisfaction jumped after launch. Real-time grades and attendance changed how we communicate.",
        "ارتفع رضا أولياء الأمور بعد الإطلاق. الدرجات والحضور اللحظي غيّر طريقة تواصلنا."
      ),
      rating: 5,
    },
  ], [t]);
}

// ════════════════════════════════════════════════════════════════════════════
// COUNTDOWN
// ════════════════════════════════════════════════════════════════════════════
function useCountdown() {
  const [target] = useState<number>(() => {
    const stored = localStorage.getItem("smartserve_offer_end");
    if (stored) return Number(stored);
    const newTarget = Date.now() + 7 * 24 * 60 * 60 * 1000;
    localStorage.setItem("smartserve_offer_end", String(newTarget));
    return newTarget;
  });
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);
  const diff = Math.max(0, target - now);
  return {
    days:    Math.floor(diff / (1000 * 60 * 60 * 24)),
    hours:   Math.floor((diff / (1000 * 60 * 60)) % 24),
    minutes: Math.floor((diff / (1000 * 60)) % 60),
    seconds: Math.floor((diff / 1000) % 60),
  };
}

function CountdownTimer() {
  const t = useT();
  const { days, hours, minutes, seconds } = useCountdown();
  const cells = [
    { label: t("Days",  "أيام"),  value: days },
    { label: t("Hours", "ساعات"), value: hours },
    { label: t("Min",   "دقائق"), value: minutes },
    { label: t("Sec",   "ثواني"), value: seconds },
  ];
  return (
    <div className="inline-flex items-center gap-3 px-5 py-3 bg-card/60 backdrop-blur-sm border border-primary/30 rounded-xl gold-glow" dir="ltr">
      <Clock className="w-5 h-5 text-primary shrink-0" />
      <div className="flex flex-col items-start">
        <span className="text-[10px] uppercase tracking-widest text-primary/80 font-semibold">
          {t("Limited-Time Offer", "عرض محدود")}
        </span>
        <div className="flex items-center gap-2 mt-1">
          {cells.map((c, i) => (
            <div key={i} className="flex items-center gap-2">
              <div className="flex flex-col items-center min-w-[34px]">
                <span className="font-mono text-lg font-bold text-foreground leading-none">
                  {String(c.value).padStart(2, "0")}
                </span>
                <span className="text-[9px] text-muted-foreground uppercase tracking-wider">{c.label}</span>
              </div>
              {i < cells.length - 1 && <span className="text-primary/50 font-bold">:</span>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// SYSTEM STATUS
// ════════════════════════════════════════════════════════════════════════════
function SystemStatus() {
  const t = useT();
  return (
    <div className="inline-flex items-center gap-2 px-4 py-2 bg-success/10 border border-success/40 rounded-full">
      <span className="relative flex w-2.5 h-2.5">
        <span className="absolute inset-0 rounded-full bg-success animate-status" />
        <span className="relative inline-flex w-2.5 h-2.5 rounded-full bg-success" />
      </span>
      <Activity className="w-3.5 h-3.5 text-success" />
      <span className="text-xs font-semibold text-success tracking-wide">
        {t("All Systems Operational", "كل الأنظمة تعمل بكفاءة")}
      </span>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// PROJECT PROFILE PDF (English-only — designed for international sharing)
// ════════════════════════════════════════════════════════════════════════════
function downloadProjectProfile() {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const w = doc.internal.pageSize.getWidth();

  doc.setFillColor(10, 10, 10);
  doc.rect(0, 0, w, 120, "F");
  doc.setTextColor(212, 175, 55);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(36);
  doc.text("SmartServe", w / 2, 70, { align: "center" });
  doc.setFontSize(12);
  doc.setTextColor(245, 245, 245);
  doc.text("Project Profile · 2026", w / 2, 95, { align: "center" });

  doc.setTextColor(40, 40, 40);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(11);

  const lines = [
    "",
    "ABOUT SMARTSERVE",
    "SmartServe is a luxury digital services studio building elegant,",
    "high-performance platforms for modern businesses across the Middle East.",
    "",
    "CORE OFFERINGS",
    "  •  Educational Suite — student records, attendance, reporting       8,000 EGP / month",
    "  •  Smart Accounting — Basic / Pro / Enterprise          From 6,000 EGP",
    "  •  Enterprise Platform — full-stack commerce + dashboard            10,000 EGP",
    "  •  Digital Menu (Basic) — QR view-only, branded                      1,500 EGP / month",
    "  •  Interactive Menu — cart, payments, live dashboard                 2,800 EGP / month",
    "",
    "INDUSTRIES SERVED",
    "Schools  ·  Hospitals  ·  Clinics  ·  Cafes & Restaurants  ·  Retail",
    "",
    "WHAT'S INCLUDED",
    "  ✓  Free 24/7 technical support — every plan, every client",
    "  ✓  Free trial experience — preview your platform before purchasing",
    "  ✓  Bilingual interface (English / Arabic) by default",
    "  ✓  Mobile-first, responsive across every screen size",
    "  ✓  PWA-ready — installable on iOS & Android",
    "",
    "CONTACT & PAYMENT",
    "  WhatsApp:        +20 127 638 7146",
    "  InstaPay:        01276387146",
    "  Vodafone Cash:   01002081026",
    "",
  ];

  let y = 160;
  lines.forEach((line) => {
    if (line === line.toUpperCase() && line.trim().length > 0 && !line.startsWith(" ")) {
      doc.setFont("helvetica", "bold");
      doc.setTextColor(212, 175, 55);
    } else {
      doc.setFont("helvetica", "normal");
      doc.setTextColor(40, 40, 40);
    }
    doc.text(line, 50, y);
    y += 16;
  });

  doc.setDrawColor(212, 175, 55);
  doc.line(50, 770, w - 50, 770);
  doc.setFontSize(9);
  doc.setTextColor(120, 120, 120);
  doc.text("All Rights Reserved © 2026 — Designed by Noha Zekry", w / 2, 790, { align: "center" });

  doc.save("SmartServe-Project-Profile.pdf");
}

// ════════════════════════════════════════════════════════════════════════════
// REGISTRATION + PAYMENT MODAL
// ════════════════════════════════════════════════════════════════════════════
const signUpSchema = z.object({
  name:     z.string().min(2, "Name is required"),
  email:    z.string().email("Valid email required"),
  phone:    z.string().min(8, "Phone required"),
  password: z.string().min(6, "Min 6 characters"),
});
type SignUpFormValues = z.infer<typeof signUpSchema>;

function PaymentInfo() {
  const t = useT();
  const { toast } = useToast();
  const copy = (txt: string, label: string) => {
    navigator.clipboard.writeText(txt);
    toast({ title: t("Copied", "تم النسخ"), description: `${label} — ${txt}` });
  };
  const items = [
    {
      label: t("WhatsApp", "واتساب"),
      value: WHATSAPP_NUMBER,
      display: "+20 127 638 7146",
      action: WHATSAPP_URL,
      isLink: true,
      color: "from-green-600 to-emerald-700",
      initials: "WA",
    },
    {
      label: t("InstaPay", "إنستاباي"),
      value: INSTAPAY_NUMBER,
      display: INSTAPAY_NUMBER,
      isLink: false,
      color: "from-violet-600 to-indigo-700",
      initials: "IP",
    },
    {
      label: t("Vodafone Cash", "فودافون كاش"),
      value: VODAFONE_NUMBER,
      display: VODAFONE_NUMBER,
      isLink: false,
      color: "from-red-600 to-red-800",
      initials: "VF",
    },
  ];
  return (
    <div className="space-y-3">
      <p className="text-xs font-bold uppercase tracking-widest text-primary/80">
        {t("Contact & Payment", "التواصل والدفع")}
      </p>
      {items.map((it) => (
        <div
          key={it.label}
          className="flex items-center gap-3 p-3 bg-background/60 border border-border/40 rounded-xl"
        >
          <div className={cn("w-10 h-10 rounded-lg bg-gradient-to-br flex items-center justify-center shrink-0", it.color)}>
            {it.isLink
              ? <MessageCircle className="w-5 h-5 text-white" />
              : <span className="font-black text-[10px] text-white tracking-tight">{it.initials}</span>}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold text-muted-foreground">{it.label}</p>
            <p className="font-mono font-bold text-foreground text-sm truncate" dir="ltr">{it.display}</p>
          </div>
          {it.isLink ? (
            <a
              href={it.action}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 bg-primary/15 hover:bg-primary text-primary hover:text-primary-foreground rounded-lg transition"
              title={t("Open WhatsApp", "افتح واتساب")}
            >
              <ArrowRight className="w-4 h-4" />
            </a>
          ) : (
            <button
              onClick={() => copy(it.value, it.label)}
              className="p-2 bg-primary/15 hover:bg-primary text-primary hover:text-primary-foreground rounded-lg transition"
              title={t("Copy number", "انسخ الرقم")}
            >
              <Copy className="w-4 h-4" />
            </button>
          )}
        </div>
      ))}
    </div>
  );
}

function RegistrationModal({
  open, onClose, serviceTitle,
}: { open: boolean; onClose: () => void; serviceTitle?: string }) {
  const t = useT();
  const { toast } = useToast();
  const [done, setDone] = useState(false);

  const { mutate, isPending } = useSignUp({
    mutation: {
      onSuccess: (data) => {
        localStorage.setItem("smartserve_token", data.token);
        setDone(true);
        toast({
          title: t("Welcome to SmartServe", "أهلاً بك في SmartServe"),
          description: t("Your account is ready.", "تم إنشاء حسابك بنجاح."),
        });
      },
      onError: (err: any) => {
        toast({
          variant: "destructive",
          title: t("Registration Failed", "فشل التسجيل"),
          description: err?.response?.data?.error || t("Something went wrong, please try again.", "حدث خطأ، حاول مرة أخرى."),
        });
      },
    },
  });

  const { register, handleSubmit, reset, formState: { errors } } = useForm<SignUpFormValues>({
    resolver: zodResolver(signUpSchema),
  });

  useEffect(() => {
    if (!open) { setDone(false); reset(); }
  }, [open, reset]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.92, y: 20, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.92, y: 20, opacity: 0 }}
            transition={{ type: "spring", duration: 0.4 }}
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-md max-h-[92vh] overflow-y-auto modal-scroll bg-card border border-primary/30 rounded-2xl p-7 gold-glow"
          >
            <button
              onClick={onClose}
              className="absolute top-4 right-4 w-9 h-9 rounded-full bg-muted/40 hover:bg-muted text-muted-foreground hover:text-foreground flex items-center justify-center transition-colors z-10"
            >
              <X className="w-4 h-4" />
            </button>

            {done ? (
              <div className="space-y-6">
                <div className="flex flex-col items-center text-center py-2 gap-3">
                  <div className="w-16 h-16 rounded-full bg-success/20 flex items-center justify-center">
                    <Check className="w-8 h-8 text-success" />
                  </div>
                  <h3 className="text-2xl font-bold text-foreground">{t("Account Created", "تم إنشاء الحساب")}</h3>
                  <p className="text-muted-foreground">
                    {t("Thanks for signing up. Here are our payment options:", "شكراً لتسجيلك. هذه طرق التواصل والدفع:")}
                  </p>
                </div>
                <PaymentInfo />
                <button
                  onClick={onClose}
                  className="w-full py-3 bg-primary text-primary-foreground rounded-lg font-semibold btn-shimmer hover:opacity-90 transition"
                >
                  {t("Done", "تم")}
                </button>
              </div>
            ) : (
              <>
                <div className="text-center mb-5">
                  <Sparkles className="w-7 h-7 text-primary mx-auto mb-2" />
                  <h3 className="text-2xl font-display font-bold text-gold-gradient mb-1">
                    {t("Get Started", "ابدأ الآن")}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {serviceTitle
                      ? t(`Sign up to start: ${serviceTitle}`, `سجل لبدء: ${serviceTitle}`)
                      : t("Sign up to start your service", "سجل لبدء خدمتك")}
                  </p>
                </div>

                <form onSubmit={handleSubmit((d) => mutate({ data: d }))} className="space-y-4">
                  {[
                    { field: "name",     icon: UserIcon,  type: "text",     placeholder: t("Full Name", "الاسم الكامل") },
                    { field: "email",    icon: Mail,      type: "email",    placeholder: t("Email",     "البريد الإلكتروني") },
                    { field: "phone",    icon: PhoneIcon, type: "tel",      placeholder: t("Phone",     "رقم الهاتف") },
                    { field: "password", icon: Lock,      type: "password", placeholder: t("Password",  "كلمة السر") },
                  ].map(({ field, icon: Icon, type, placeholder }) => {
                    const err = errors[field as keyof SignUpFormValues];
                    return (
                      <div key={field}>
                        <div className="relative">
                          <Icon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                          <input
                            {...register(field as keyof SignUpFormValues)}
                            type={type}
                            placeholder={placeholder}
                            className={cn(
                              "w-full pl-10 pr-4 py-3 bg-input border border-border/50 rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition",
                              err && "border-red-500/70 focus:border-red-500 focus:ring-red-500"
                            )}
                          />
                        </div>
                        {err && <p className="text-red-400 text-xs mt-1 ml-1">{err.message}</p>}
                      </div>
                    );
                  })}

                  <button
                    type="submit"
                    disabled={isPending}
                    className="w-full py-3.5 bg-primary text-primary-foreground rounded-lg font-bold btn-shimmer hover:shadow-[0_0_24px_rgba(212,175,55,0.4)] transition disabled:opacity-60"
                  >
                    {isPending ? t("Creating account...", "جاري إنشاء الحساب...") : t("Create Account", "إنشاء حساب")}
                  </button>
                </form>
              </>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// SERVICE MODAL (mini-dashboard)
// ════════════════════════════════════════════════════════════════════════════
function ServiceModal({
  service, onClose, onGetStarted,
}: { service: Service | null; onClose: () => void; onGetStarted: (s: Service) => void }) {
  const t = useT();
  const industries = useIndustries();
  const [industry, setIndustry] = useState<IndustryKey>("cafes");
  const [open, setOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  useEffect(() => {
    if (service) { setIndustry("cafes"); setOpen(false); setOpenFaq(0); }
  }, [service]);

  const features = useMemo(
    () => (service ? service.features[industry] : []),
    [service, industry],
  );
  const currentIndustry = industries.find((i) => i.key === industry);

  return (
    <AnimatePresence>
      {service && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.92, y: 30, opacity: 0 }}
            animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.92, y: 30, opacity: 0 }}
            transition={{ type: "spring", duration: 0.45 }}
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-3xl max-h-[92vh] overflow-y-auto modal-scroll bg-card border border-primary/30 rounded-2xl gold-glow-strong"
          >
            {/* Header */}
            <div className="sticky top-0 z-10 flex items-start justify-between gap-4 p-6 md:p-8 bg-card/95 backdrop-blur-sm border-b border-border/30">
              <div className="flex items-start gap-4">
                <div className="w-14 h-14 rounded-xl bg-primary/15 border border-primary/30 flex items-center justify-center shrink-0">
                  <service.icon className="w-7 h-7 text-primary" />
                </div>
                <div>
                  <h2 className="text-2xl md:text-3xl font-display font-bold text-gold-gradient">{service.title}</h2>
                  <p className="text-muted-foreground mt-0.5">{service.tagline}</p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="w-9 h-9 rounded-full bg-muted/40 hover:bg-muted text-muted-foreground hover:text-foreground flex items-center justify-center transition-colors shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 md:p-8 space-y-8">
              {/* Description + headline price */}
              <div>
                <p className="text-foreground/85 leading-relaxed">{service.description}</p>
                {!service.tiers && (
                  <div className="mt-4 inline-flex items-center gap-3 px-4 py-2 bg-primary/10 border border-primary/30 rounded-lg">
                    <span className="text-2xl font-bold text-primary">{service.price}</span>
                  </div>
                )}
              </div>

              {/* Pricing tiers */}
              {service.tiers && (
                <div>
                  <h4 className="text-sm font-bold uppercase tracking-widest text-primary/80 mb-3">
                    {t("Pricing Tiers", "باقات الأسعار")}
                  </h4>
                  <div className="grid sm:grid-cols-3 gap-3">
                    {service.tiers.map((tier, i) => (
                      <div
                        key={i}
                        className={cn(
                          "relative p-5 rounded-xl border bg-background/40 transition-all",
                          i === 1
                            ? "border-primary/60 gold-glow scale-[1.02]"
                            : "border-border/40"
                        )}
                      >
                        {i === 1 && (
                          <span className="absolute -top-2.5 left-1/2 -translate-x-1/2 px-2.5 py-0.5 bg-primary text-primary-foreground text-[10px] font-bold uppercase tracking-wider rounded-full whitespace-nowrap">
                            {t("Popular", "الأكثر طلباً")}
                          </span>
                        )}
                        <p className="text-sm font-bold text-primary uppercase tracking-wide mb-1">{tier.name}</p>
                        <p className="text-2xl font-bold text-foreground mb-3">{tier.price}</p>
                        <ul className="space-y-1.5">
                          {tier.features.map((f, j) => (
                            <li key={j} className="flex items-start gap-1.5 text-xs text-foreground/80">
                              <Check className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
                              <span>{f}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Industry selector */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-widest text-primary/80 mb-2">
                  {t("Choose your industry", "اختر مجالك")}
                </label>
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setOpen((v) => !v)}
                    className="w-full flex items-center justify-between px-5 py-4 bg-input border border-border/50 hover:border-primary/60 rounded-xl text-foreground font-medium transition-colors"
                  >
                    <span>{currentIndustry?.label}</span>
                    <ChevronDown className={cn("w-4 h-4 transition-transform", open && "rotate-180")} />
                  </button>
                  <AnimatePresence>
                    {open && (
                      <motion.ul
                        initial={{ opacity: 0, y: -6 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -6 }}
                        className="absolute z-20 left-0 right-0 mt-2 bg-card border border-border/60 rounded-xl shadow-2xl overflow-hidden"
                      >
                        {industries.map((opt) => (
                          <li key={opt.key}>
                            <button
                              onClick={() => { setIndustry(opt.key); setOpen(false); }}
                              className={cn(
                                "w-full flex items-center justify-start px-5 py-3 text-left hover:bg-primary/10 transition-colors",
                                industry === opt.key && "bg-primary/15 text-primary"
                              )}
                            >
                              <span className="font-medium">{opt.label}</span>
                            </button>
                          </li>
                        ))}
                      </motion.ul>
                    )}
                  </AnimatePresence>
                </div>
              </div>

              {/* Features */}
              <div>
                <h4 className="text-sm font-bold uppercase tracking-widest text-primary/80 mb-3">
                  {t("What's Included", "المميزات")}
                </h4>
                <AnimatePresence mode="wait">
                  <motion.ul
                    key={industry + service.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.25 }}
                    className="grid sm:grid-cols-2 gap-2.5"
                  >
                    {features.map((f, i) => (
                      <li key={i} className="flex items-start gap-2.5 px-4 py-3 bg-background/40 border border-border/30 rounded-lg">
                        <Check className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                        <span className="text-sm text-foreground/90">{f}</span>
                      </li>
                    ))}
                  </motion.ul>
                </AnimatePresence>
              </div>

              {/* Trust badges */}
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="p-5 bg-gradient-to-br from-primary/10 via-card to-card border border-primary/40 rounded-xl gold-glow-pulse">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
                      <Headphones className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-bold text-foreground">{t("Free 24/7 Support", "دعم مجاني على مدار الساعة")}</p>
                      <p className="text-xs text-muted-foreground">{t("Always here when you need us", "نحن هنا متى احتجت لنا")}</p>
                    </div>
                  </div>
                </div>
                <div className="p-5 bg-gradient-to-br from-primary/10 via-card to-card border border-primary/40 rounded-xl gold-glow-pulse">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
                      <Gift className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-bold text-foreground">{t("Free Trial Experience", "تجربة مجانية")}</p>
                      <p className="text-xs text-muted-foreground">{t("Try it before you commit", "جرب قبل الالتزام")}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Quick FAQ */}
              <div>
                <h4 className="text-sm font-bold uppercase tracking-widest text-primary/80 mb-3">
                  {t("Quick FAQ", "أسئلة شائعة")}
                </h4>
                <div className="space-y-2">
                  {service.faq.map((item, i) => {
                    const isOpen = openFaq === i;
                    return (
                      <div
                        key={i}
                        className="bg-background/40 border border-border/40 rounded-lg overflow-hidden"
                      >
                        <button
                          onClick={() => setOpenFaq(isOpen ? null : i)}
                          className="w-full flex items-center justify-between gap-3 px-4 py-3 text-left hover:bg-primary/5 transition-colors"
                        >
                          <span className="text-sm font-semibold text-foreground">{item.q}</span>
                          <Plus className={cn("w-4 h-4 text-primary shrink-0 transition-transform", isOpen && "rotate-45")} />
                        </button>
                        <AnimatePresence initial={false}>
                          {isOpen && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: "auto", opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.25 }}
                              className="overflow-hidden"
                            >
                              <p className="px-4 pb-4 text-sm text-muted-foreground leading-relaxed">{item.a}</p>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* CTAs */}
              <div className="grid sm:grid-cols-2 gap-3">
                <button
                  onClick={() => onGetStarted(service)}
                  className="py-4 bg-primary text-primary-foreground rounded-xl font-bold btn-shimmer hover:shadow-[0_0_30px_rgba(212,175,55,0.5)] transition-all flex items-center justify-center gap-2"
                >
                  <span className="text-base">{t("Get Started", "اطلب الآن")}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <a
                  href={`${WHATSAPP_URL}?text=${encodeURIComponent(`Hi! I'm interested in: ${service.title}`)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-4 bg-[#25D366] text-white rounded-xl font-bold hover:scale-[1.02] hover:shadow-[0_0_30px_rgba(37,211,102,0.45)] transition-all flex items-center justify-center gap-2"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span className="text-base">{t("WhatsApp", "تواصل واتساب")}</span>
                </a>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// FLOATING WHATSAPP BUTTON (auto-mirrors based on direction)
// ════════════════════════════════════════════════════════════════════════════
function FloatingWhatsApp() {
  const t = useT();
  const { dir } = useLang();
  return (
    <a
      href={WHATSAPP_URL}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={t("Chat on WhatsApp", "تواصل عبر واتساب")}
      className={cn(
        "fixed bottom-5 z-[60] flex items-center justify-center w-14 h-14 bg-[#25D366] text-white rounded-full",
        "shadow-[0_0_24px_rgba(37,211,102,0.55)] hover:scale-110 active:scale-95 transition-transform animate-status",
        dir === "rtl" ? "left-5" : "right-5"
      )}
      style={{ animationDuration: "3s" }}
    >
      <svg className="w-7 h-7 fill-current" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
        <path d="M16.004 2.667C8.636 2.667 2.667 8.636 2.667 16.004c0 2.34.616 4.53 1.69 6.427L2.667 29.333l7.12-1.663a13.27 13.27 0 0 0 6.217 1.548c7.368 0 13.337-5.969 13.337-13.337C29.341 8.513 23.372 2.667 16.004 2.667zm6.034 18.99c-.33-.165-1.95-.96-2.253-1.076-.302-.115-.521-.165-.74.165-.22.33-.847 1.076-1.04 1.295-.19.22-.385.247-.715.082-.33-.165-1.39-.513-2.65-1.635-.98-.873-1.64-1.952-1.834-2.282-.192-.33-.02-.51.145-.674.15-.148.33-.385.495-.578.165-.192.22-.33.33-.55.11-.22.055-.412-.027-.578-.083-.165-.74-1.786-1.015-2.447-.264-.643-.53-.56-.74-.56-.192-.007-.412-.007-.632-.007a1.21 1.21 0 0 0-.88.412c-.302.33-1.154 1.129-1.129 2.75 0 1.62 1.182 3.188 1.347 3.408.165.22 2.327 3.556 5.643 4.989.788.342 1.403.546 1.883.698.79.25 1.51.215 2.078.13.634-.094 1.95-.797 2.226-1.566.274-.77.274-1.43.192-1.566-.082-.137-.302-.22-.632-.385z" />
      </svg>
    </a>
  );
}

// ════════════════════════════════════════════════════════════════════════════
// MAIN PAGE
// ════════════════════════════════════════════════════════════════════════════
export default function Home() {
  const t = useT();
  const services = useServices();
  const testimonials = useTestimonials();
  const [activeService, setActiveService] = useState<Service | null>(null);
  const [registerOpen, setRegisterOpen] = useState(false);
  const [registerService, setRegisterService] = useState<string | undefined>();
  const { toast } = useToast();

  const openRegister = (svc?: Service) => {
    setActiveService(null);
    setRegisterService(svc?.title);
    setTimeout(() => setRegisterOpen(true), 100);
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">

      {/* ─── NAV ───────────────────────────────────────────────────── */}
      <header className="sticky top-0 z-40 bg-background/80 backdrop-blur-md border-b border-primary/15">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-3 px-4 sm:px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-primary to-yellow-700 flex items-center justify-center font-display font-black text-background text-lg">S</div>
            <span className="font-display font-bold text-xl text-gold-gradient tracking-wide">SmartServe</span>
          </div>
          <div className="hidden md:block"><SystemStatus /></div>
          <div className="flex items-center gap-2">
            <LangToggle />
            <button
              onClick={() => setRegisterOpen(true)}
              className="px-4 py-2 bg-primary/15 hover:bg-primary text-primary hover:text-primary-foreground border border-primary/40 rounded-lg font-semibold text-sm transition-all"
            >
              {t("Sign In", "دخول")}
            </button>
          </div>
        </div>
      </header>

      {/* ─── HERO ──────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-grid opacity-60" />
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background/40 to-background" />
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-primary/10 rounded-full blur-[120px]" />

        <div className="relative max-w-6xl mx-auto px-6 pt-14 pb-16 md:pt-20 md:pb-24 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 bg-primary/10 border border-primary/30 rounded-full mb-6"
          >
            <Sparkles className="w-3.5 h-3.5 text-primary" />
            <span className="text-xs font-semibold tracking-widest uppercase text-primary">
              {t("Luxury in Simplicity", "الفخامة في البساطة")}
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="text-5xl md:text-7xl lg:text-8xl font-display font-black mb-4"
          >
            <span className="text-gold-gradient">SmartServe</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="text-lg md:text-2xl text-foreground/80 max-w-2xl mx-auto mb-10"
          >
            {t(
              "Premium digital platforms — engineered for elegance, built for scale.",
              "منصات رقمية فاخرة — صُممت بأناقة، وبُنيت لتدوم"
            )}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.4 }}
            className="flex flex-col items-center gap-6"
          >
            <CountdownTimer />

            <div className="flex flex-wrap items-center justify-center gap-3">
              <a
                href="#services"
                className="inline-flex items-center gap-2 px-7 py-3.5 bg-primary text-primary-foreground rounded-lg font-bold btn-shimmer hover:shadow-[0_0_30px_rgba(212,175,55,0.5)] transition"
              >
                {t("Browse Services", "استعرض الخدمات")} <ArrowRight className="w-4 h-4" />
              </a>
              <button
                onClick={() => {
                  downloadProjectProfile();
                  toast({ title: t("Downloading", "جاري التحميل"), description: t("Project Profile PDF", "ملف تعريف المشروع PDF") });
                }}
                className="inline-flex items-center gap-2 px-7 py-3.5 bg-transparent border border-primary/50 text-primary hover:bg-primary/10 hover:border-primary rounded-lg font-bold transition"
              >
                <Download className="w-4 h-4" />
                {t("Download Project Profile", "تحميل ملف المشروع")}
              </button>
            </div>

            <div className="md:hidden"><SystemStatus /></div>
          </motion.div>
        </div>
      </section>

      {/* ─── SERVICES GRID ─────────────────────────────────────────── */}
      <section id="services" className="relative py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <p className="text-xs font-semibold tracking-widest uppercase text-primary/80 mb-2">
              {t("Our Core Services", "خدماتنا الأساسية")}
            </p>
            <h2 className="text-4xl md:text-5xl font-display font-bold text-foreground">
              {t("Choose your", "اختر")} <span className="text-gold-gradient">{t("platform", "منصتك")}</span>
            </h2>
            <p className="text-muted-foreground mt-2">
              {t("Browse our services and pick what fits your project.", "تصفح خدماتنا واختر ما يناسب مشروعك")}
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {services.map((svc, i) => (
              <motion.button
                key={svc.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.5, delay: (i % 3) * 0.1 }}
                onClick={() => setActiveService(svc)}
                className="group relative text-left bg-card border border-border/40 hover:border-primary/60 rounded-2xl p-6 transition-all duration-500 hover:-translate-y-1 hover:gold-glow-strong"
              >
                <div className="absolute top-0 left-7 right-7 h-px bg-gradient-to-r from-transparent via-primary/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

                <div className="w-13 h-13 rounded-xl bg-primary/10 border border-primary/25 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors p-3">
                  <svc.icon className="w-7 h-7 text-primary" />
                </div>

                <h3 className="text-xl font-display font-bold text-foreground mb-1">{svc.title}</h3>
                <p className="text-sm text-foreground/70 mb-4 leading-relaxed">{svc.tagline}</p>

                <div className="flex items-center justify-between pt-4 border-t border-border/30">
                  <span className="text-xl font-bold text-primary">{svc.price}</span>
                  <span className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary group-hover:gap-3 transition-all">
                    {t("Details", "التفاصيل")} <ArrowRight className="w-4 h-4" />
                  </span>
                </div>
              </motion.button>
            ))}
          </div>
        </div>
      </section>

      {/* ─── TRUST STRIP ──────────────────────────────────────────── */}
      <section className="py-14 border-y border-primary/10 bg-card/40">
        <div className="max-w-5xl mx-auto px-6 grid md:grid-cols-3 gap-5">
          {[
            { icon: ShieldCheck, label: t("Free 24/7 Technical Support", "دعم فني مجاني على مدار الساعة") },
            { icon: Gift,        label: t("Free Trial Experience",       "تجربة مجانية للخدمة") },
            { icon: Zap,         label: t("Bilingual & Mobile-First",    "ثنائي اللغة ومتوافق مع الجوال") },
          ].map((item, i) => (
            <div
              key={i}
              className="flex items-center gap-4 p-5 bg-background/60 border border-primary/20 rounded-xl gold-glow-pulse"
              style={{ animationDelay: `${i * 0.4}s` }}
            >
              <div className="w-12 h-12 rounded-full bg-primary/15 flex items-center justify-center shrink-0">
                <item.icon className="w-5 h-5 text-primary" />
              </div>
              <p className="font-bold text-foreground">{item.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ─── TESTIMONIALS ─────────────────────────────────────────── */}
      <section id="stories" className="py-16 md:py-24 relative">
        <div className="max-w-6xl mx-auto px-4 sm:px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <p className="text-xs font-semibold tracking-widest uppercase text-primary/80 mb-2">
              {t("Success Stories", "قصص النجاح")}
            </p>
            <h2 className="text-4xl md:text-5xl font-display font-bold text-foreground">
              {t("Trusted by", "موثوق من")} <span className="text-gold-gradient">{t("leaders", "الرواد")}</span>
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-5">
            {testimonials.map((tt, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="relative bg-card border border-border/40 rounded-2xl p-6 hover:border-primary/50 hover:gold-glow transition-all duration-500"
              >
                <Quote className="absolute top-5 right-5 w-8 h-8 text-primary/20" />
                <div className="flex gap-0.5 mb-4">
                  {Array.from({ length: tt.rating }).map((_, k) => (
                    <Star key={k} className="w-4 h-4 fill-primary text-primary" />
                  ))}
                </div>
                <p className="text-foreground/90 leading-relaxed mb-6">"{tt.quote}"</p>
                <div className="pt-4 border-t border-border/30">
                  <p className="font-bold text-foreground">{tt.name}</p>
                  <p className="text-sm text-muted-foreground">{tt.role}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── FOOTER ───────────────────────────────────────────────── */}
      <div className="mt-auto"><SharedFooter /></div>

      {/* ─── MODALS & FLOATING CTA ────────────────────────────────── */}
      <ServiceModal
        service={activeService}
        onClose={() => setActiveService(null)}
        onGetStarted={openRegister}
      />
      <RegistrationModal
        open={registerOpen}
        onClose={() => setRegisterOpen(false)}
        serviceTitle={registerService}
      />
      <FloatingWhatsApp />
    </div>
  );
}
